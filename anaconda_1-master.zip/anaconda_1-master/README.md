# anaconda_1
Deberes de Python desde Anaconda Deberes
https://anaconda.org/marsgr6/deberes_ms_2020_01/notebook